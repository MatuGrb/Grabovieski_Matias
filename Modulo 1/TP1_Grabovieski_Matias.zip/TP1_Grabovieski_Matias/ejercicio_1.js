document.write("Hola Mundo!");
// muestra el mensaje en la pagina web